
PROJECT SIGNAL — DASHBOARD ARTIFACTS

signal_repeat_purchase_model.joblib:
    Final trained logistic regression pipeline.
    Includes preprocessing and classifier.

model_metadata.json:
    Model features, target, prediction horizon and evaluation.

transactions.csv:
    Cleaned transaction-level data.

orders.csv:
    Order-level analytical data.

customers_rfm.csv:
    Customer RFM scores and segments.

at_risk_customers.csv:
    At-risk customer cadence and prioritisation information.

retention_strategy.csv:
    Proposed segment-level retention recommendations.

targeting_results.csv:
    Validation operational targeting results.

final_model_evaluation.csv:
    Final held-out model evaluation.

IMPORTANT:
The predictive model is exploratory and is not deployment-ready.
Its test ROC-AUC was 0.5725.
Do not interpret predictions as guaranteed customer behaviour.
